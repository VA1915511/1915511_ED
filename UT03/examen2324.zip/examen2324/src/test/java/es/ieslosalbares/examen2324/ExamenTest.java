/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package es.ieslosalbares.examen2324;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 *
 * @author alumnociclo
 */
public class ExamenTest {
    
    public ExamenTest() {
    }

    /**
     * Test of finalFour method, of class Examen.
     */
    @ParameterizedTest
    @CsvSource ({
    "1, 1, Campeón",
    "1, 0, Subcampeón",
    "0, 1, Tercero",
    "0, 0, Cuarto"
    })
    public void testFinalFour(int partido1, int partido2, String res) {
        System.out.println("finalFour");
        Examen instance = new Examen();
        String expResult = res;
        String result = instance.finalFour(partido1, partido2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of numeroCapicua method, of class Examen.
     */
    @Test
    public void testNumeroCapicua() {
        System.out.println("numeroCapicua");
        int numero = 0;
        Examen instance = new Examen();
        //boolean expResult = true;
        boolean result = instance.numeroCapicua(numero);
        assertTrue(result);
        assertFalse(result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of primerNumero method, of class Examen.
     */
    @ParameterizedTest
    @CsvSource ({
    "1, 1",
    "10 , 1",
    "100 , 1",
    "1000, 1",
    "10000, 1"
    })
    public void testPrimerNumero(int n, int res) {
        System.out.println("primerNumero");
        Examen instance = new Examen();
        int expResult = res;
        int result = instance.primerNumero(n);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of piedraPapelTijera method, of class Examen.
     */
    @ParameterizedTest
    @CsvSource ({
    "piedra, piedra, Empate",
    "piedra, papel, jugador2",
    "piedra, tijera, jugador1",
    "papel, papel, Empate",
    "papel, piedra, jugador1",
    "papel, tijera, jugador2",
    "Tijera, Tijera, Empate",
    "tijera, papel, jugador1",
    "tijera, piedra, jugador2",
    })
    public void testPiedraPapelTijera(String jugador1, String jugador2, String res) {
        System.out.println("piedraPapelTijera");
        Examen instance = new Examen();
        String expResult = res;
        String result = instance.piedraPapelTijera(jugador1, jugador2);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
