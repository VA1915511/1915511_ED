/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package es.victor.finalentornos;

/**
 *
 * @author Victor Aznar
 */
public class Finalentornos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
