/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

/**
 *
 * @author alumnociclo
 */
public abstract class Ciclista extends Persona{
    
    private String modalidad;
    private long tiempo;

    public Ciclista(String dni, String nombre, int edad, String pais, String modalidad, long tiempo) {
        super(dni, nombre, edad, pais);
        this.modalidad = modalidad;
        this.tiempo = tiempo;
    }

    /**
     * @return the modalidad
     */
    public String getModalidad() {
        return modalidad;
    }

    /**
     * @param modalidad the modalidad to set
     */
    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    /**
     * @return the tiempo
     */
    public long getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(long tiempo) {
        this.tiempo = tiempo;
    }
    
    @Override
    public String toString(){
    
        return super.toString() +
                "\nEsta persona es un ciclista." + 
                "\nLa modalidad en la que compite es: " + getModalidad() +
                "\nEl tiempo que ha tardado en completar el circuito es: " + getTiempo() + " horas.";
    
    }
    
}
