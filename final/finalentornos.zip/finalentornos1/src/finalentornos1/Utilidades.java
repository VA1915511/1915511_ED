/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package finalentornos1;

/**
 *
 * @author Victor
 */
public abstract interface Utilidades {
    
    public abstract void mejorar(long a);

    public abstract void comparar(Persona p1, Persona p2);
    
}
