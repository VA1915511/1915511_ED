/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

/**
 *
 * @author alumnociclo
 */
public abstract class Corredor extends Persona{
    
    private String competencia;
    private long tiempo;

    public Corredor(String dni, String nombre, int edad, String pais, String competencia, long tiempo) {
        super(dni, nombre, edad, pais);
        this.competencia = competencia;
        this.tiempo = tiempo;
    }
    
    public Corredor(String dni, String nombre, int edad, String pais, String competencia) {
        super(dni, nombre, edad, pais);
        this.competencia = competencia;
    }

    /**
     * @return the competencia
     */
    public String getCompetencia() {
        return competencia;
    }

    /**
     * @param competencia the competencia to set
     */
    public void setCompetencia(String competencia) {
        this.competencia = competencia;
    }

    /**
     * @return the tiempo
     */
    public long getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(long tiempo) {
        this.tiempo = tiempo;
    }
    
    @Override
    public String toString(){
    
        return super.toString() +
                "\nEsta persona es un corredor." + 
                "\nLa competencia en la que compite es: " + getCompetencia() +
                "\nEl tiempo que ha tardado en completar el circuito es: " + getTiempo() + " minutos.";
    
    }
    
    @Override
    public void mejorar(long a) {
        
        
        
    }
    
}
