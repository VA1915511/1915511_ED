/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author alumnociclo
 */
public class ComNatacion extends Competicion{

    LinkedList <Nadador> ranking;
    LinkedList <Nadador> participantes;
    Scanner sc = new Scanner(System.in);
    
    @Override
    public void addParticipante(Persona p1){
    
        p1 = new Nadador(p1.getDni(), p1.getNombre(), p1.getEdad(), p1.getPais(), "Crol", 100);
    
        participantes.add((Nadador) p1);
        
    }
     

    public void addRanking(Nadador n1){
    
        n1 = participantes.pop();
        System.out.println("Introduce el tiempo de este nadador");
        long tiempo = sc.nextLong();
        sc.nextLine();
        
        n1.setTiempo(tiempo);
    
    }
    
    /*@Override
    public void comparar(Persona p1, Persona p2) {
        
    }

    @Override
    public void Ranking(Persona p1) {
        p1 = new Nadador("2020", "Juan", 20, "España", "Crol", 100, 30);
    }*/
    
    
    
    
}
