/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

import java.util.LinkedList;

/**
 *
 * @author alumnociclo
 */
public class ComNatacion extends Competicion{

    LinkedList <Nadador> ranking;
     
    /*@Override
    public void comparar(Persona p1, Persona p2) {
        
    }

    @Override
    public void Ranking(Persona p1) {
        p1 = new Nadador("2020", "Juan", 20, "España", "Crol", 100, 30);
    }*/
    
    
    
    
}
