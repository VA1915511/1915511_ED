/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

/**
 *
 * @author Victor
 */
public class Nadador extends Persona{
    
    private String estilo;  //Estilo de natacion (crol, mariposa, braza, espalda)
    private int distancia;  //Distancia recorrida en el estilo elegido (50, 100, 200, 400 metros)
    private long tiempo;    //Tiempo que ha tardado en recorrer la distancia en el estilo elegido

    public Nadador(String dni, String nombre, int edad, String pais, String estilo, int distancia, long tiempo) {
        super(dni, nombre, edad, pais);
        this.estilo = estilo;
        this.distancia = distancia;
        this.tiempo = tiempo;
    }

    /**
     * @return the estilo
     */
    public String getEstilo() {
        return estilo;
    }

    /**
     * @param estilo the estilo to set
     */
    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    /**
     * @return the distancia
     */
    public int getDistancia() {
        return distancia;
    }

    /**
     * @param distancia the distancia to set
     */
    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    /**
     * @return the tiempo
     */
    public long getTiempo() {
        return tiempo;
    }

    /**
     * @param tiempo the tiempo to set
     */
    public void setTiempo(long tiempo) {
        this.tiempo = tiempo;
    }
    
    @Override
    public String toString(){
    
        return super.toString() +
                "\nEsta persona es un nadador." + 
                "\nEl estilo de este nadador es: " + getEstilo() +
                "\nLa distancia que recorre es: " + getDistancia() +
                "\nEl tiempo que ha tardado es: " + getTiempo() + " segundos.";
    
    }

    @Override
    public void mejorar(long a) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
