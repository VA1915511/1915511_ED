/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

import java.util.LinkedList;

/**
 *
 * @author alumnociclo
 */
public class Competicion {
    
    LinkedList <Persona> participantes = new LinkedList();
    LinkedList <Persona> ranking = new LinkedList();
    
    private String tipo;
    //private Persona[] ranking = new Persona[3];
    
}
