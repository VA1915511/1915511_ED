/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

import java.util.LinkedList;

/**
 *
 * @author alumnociclo
 */
abstract class Competicion{
    
    LinkedList <Persona> ranking;
    
    public String topTres(){
    
        return "El ganador de la competicion es: " + ranking.getFirst() +
                "\nEl segundo lugar es: " + ranking.get(1) + 
                "\nEl tercer lugar es: " + ranking.get(2);
    
    }
    
    public String clasificacion(int i) throws IndexOutOfBoundsException{
        
        String s;
        
        try{
            
            if(i-1 <= 2){

                s = "Para el ranking del top 3 mejor usa el metodo topTres()";

            }else{

                s = "El " + i + "º lugar ha sido ocupado por: " +
                        ranking.get(i).getNombre();

            }
        
        }catch(IndexOutOfBoundsException e){
        
            s = "Numero de ranking no encontrado";
            
        }
        return s;
    
    }
    
    public void addParticipante(Persona p1){}
    
}
