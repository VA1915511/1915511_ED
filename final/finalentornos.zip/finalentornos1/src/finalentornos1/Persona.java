/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalentornos1;

/**
 *
 * @author Victor
 */
public abstract class Persona implements Utilidades{
    
    private String dni;
    private String nombre;
    private int edad;
    private String pais;

    public Persona(String dni, String nombre, int edad, String pais) {
        this.dni = dni;
        this.nombre = nombre;
        this.edad = edad;
        this.pais = pais;
    }
    
    public Persona(){}

    /**
     * @return the dni
     */
    public String getDni() {
        return dni;
    }

    /**
     * @param dni the dni to set
     */
    public void setDni(String dni) {
        
        this.dni = dni;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the edad to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    /**
     * @return the pais
     */
    public String getPais() {
        return pais;
    }

    /**
     * @param pais the pais to set
     */
    public void setPais(String pais) {
        this.pais = pais;
    }
    
    @Override
    public String toString(){

        return "El nombre de esta persona es: " + getNombre() + 
                "\nSu DNI es: " + getDni() + 
                "\nSu edad es: " + getEdad() + " años" + 
                "\nSu pais de procedencia es: " + getPais();
    
    }

    @Override
    public void mejorar(long a){}
    
}
