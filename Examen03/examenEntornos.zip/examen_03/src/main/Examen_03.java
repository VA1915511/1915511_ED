
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
//He cambiado el nombre del package a main
package main;

//He añadido los imports de Asignatura, Examen y Scanner

import examen_03.Estudiante;
import examen_03.Asignatura;
import java.util.Scanner;


/**
 *
 * @author Victor
 */


public class Examen_03 {

        //He creado estas dos variables en la clase para que lo cojan todos los metodos
        //He añadido el array de clase Estudiante
        static Estudiante[] estudiantes = new Estudiante[5];
        //He creado el array ASIGNATURAS
        static Asignatura[] ASIGNATURAS = new Asignatura[5];
        
    
    
    
    /**
     *
     * @param args
     */
    public static void main(String[] args) {

        //He añadido el Scanner teclado
        Scanner teclado = new Scanner(System.in);
        //He borrado el valor predefinido de opcion ya que se establece luego con el Scanner
        int opcion;

        do {
                System.out.println("\n\t\tMENU UNIVERSIDAD");
                System.out.println("\t\t---- -----------\n");
                System.out.println("[1] -- Registrar nuevos Estudiantes");
                System.out.println("[2] -- Listar notas definitivas de Asignaturas por cada Estudiante");
                System.out.println("[3] -- Listar promedio general de cada Estudiante");
                System.out.println("[4] -- Listar promedio de nota definitiva de todos los Estudiantes por Asignatura");
                System.out.println("[9] -- TERMINAR PROGRAMA");
                System.out.print("Opcion: ");
                opcion = Integer.parseInt(teclado.nextLine());
                switch(opcion) {
                case 1:
                        registrarNuevosEstudiantes();
                        break;
                case 2:
                        listarNotasDefinitivas();
                        break;
                case 3:
                        listarPromedioEstudiantes();
                        break;
                case 4:
                        listarPromediosNotasDefinitivas();
                        break;
                case 9:
                        System.out.println("\n\t\tFIN DE PROGRAMA");
                        break;
                default:
                        System.out.println("Opción equivocada");
                }
        } while(opcion != 9);		                   
    }
           		
    private static void listarNotasDefinitivas() {
        if (estudiantes == null) {
            System.out.println("No hay Estudiantes registrados.");
        } else {
            System.out.println("\n\tNOTAS DEFINITIVAS POR ESTUDIANTES");
            //Recorremos cada Asignatura
            for (int asig = 0; asig < ASIGNATURAS.length; asig++) {
                System.out.println("\n- Asignatura: " + ASIGNATURAS[asig]);
                //Recorremos cada Estudiante para obtener su nota en la Asignatura actual
                for (Estudiante estu : estudiantes) {
                    System.out.println("Nombre: " + estu.getNombre());
                    System.out.println("Nota Definitiva: " + estu.getNotaDeAsignatura(asig));
                }
            }
        }
    }

    private static void listarPromedioEstudiantes() {
        if (estudiantes == null) {
            System.out.println("No hay Estudiantes registrados.");
        } else {
            System.out.println("\n\tPROMEDIO GENERAL POR ESTUDIANTES");
            //Recorremos Estudiantes y les pedimos su promedio
            for (Estudiante estu : estudiantes) {
                System.out.println("\nNombre: " + estu.getNombre());
                System.out.println("Promedio General: " + estu.getPromedioGeneral());
            }
        }
    }


    
        private static void listarPromediosNotasDefinitivas() {
            if (estudiantes == null)
                    System.out.println("No hay Estudiantes registrados.");
            else {
                    System.out.println("\n\tPROMEDIOS NOTAS DEFINITIVAS");
                    //Recorremos Asignaturas
                    for (int asig= 0; asig < ASIGNATURAS.length; asig++) {
                            System.out.println("\nAsignatura: " + ASIGNATURAS[asig]);
                            /*
                             * Por cada Asignatura, sumamos las notas definitivas de los 
                             * 5 Estudiantes. Con esta suma, luego calcularemos el promedio
                             */
                            int sumaNotas = 0;
                            for (Estudiante estu: estudiantes)
                                    sumaNotas += estu.getNotaDeAsignatura(asig);
                            //Tenemos la suma, calculamos promedio
                            System.out.println("Promedio de notas: " + (sumaNotas/estudiantes.length));
                    }
                }
        }

    private static void registrarNuevosEstudiantes() {

        //Proceso para registrar nuevos estudiantes
        //Inicializamos array de Estudiantes
        //He creado un Scanner en este metodo
        Scanner teclado = new Scanner(System.in);
        

        //Por cada Estudiante, registraremos 5 Asignaturas, con 3 notas parciales
        for (int est = 0; est < estudiantes.length; est++) {
                System.out.println("\n\nRegistrando Estudiante #" + (est+1));
                System.out.print("Nombre: ");
                String nombre = teclado.nextLine();
                //Registramos Estudiante en el array
                estudiantes[est] = new Estudiante(nombre);
        
        //Para este Estudiante, registramos ahora 5 Asignaturas
        for (int asig = 0; asig < ASIGNATURAS.length; asig++) {
                    
                //He creado un String para el nombre de cada asignatura
                String nombreAsig = teclado.nextLine();
                //Construimos la Asignatura, tomando el nombre del array predefinido
                Asignatura asignatura = new Asignatura(nombreAsig);
                
                //Ahora, hay que pedir 3 notas parciales para esta Asignatura
                System.out.println("\nNotas parciales de " + asignatura);
                for (int i = 0; i < 3; i++) {
                    System.out.print("Parcial #" + (i+1) + ": ");
                    int parcial = Integer.parseInt(teclado.nextLine());
                    //Registramos parcial en la Asignatura, indicando la posición donde debe registrarse
                    asignatura.registrarNotaParcial(parcial, i);
                }

                /*
                 * Ya tenemos Asignatura con las 3 notas parciales.
                 * La registramos en el Estudiante, indicando la posicion donde registrarse
                 */
                estudiantes[est].registrarAsignatura(asignatura, asig);
                }
                //Aqui termina el bucle para registrar 5 Asignaturas.
                //Ahora se volverá a repetir el ciclo para otro Estudiante, hasta completar los 5
        }
    }
}
