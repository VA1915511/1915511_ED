//He añadidio el package
package examen_03;

/**
 *
 * @author alumnociclo
 */
public class Estudiante {
	
	//Cada Estudiante tiene 5 asignaturas
        //He cambiado la clase del array de asi a Asignatura
	private Asignatura[] asignaturas = new Asignatura[5];
	private String nombre;
	
        //He creado el constructor de Estudiante

    /**
     *
     * @param nombre
     */
        public Estudiante(String nombre){
            this.nombre = nombre;
        }
        
	/**
        * @return la variable nombre
        */
        public String getNombre() {
           return nombre;
        }

        /**
        * @param nombre setter del nombre
        */
        public void setNombre(String nombre) {
           this.nombre = nombre;
        }
	
	/*
	 * Registra una Asignatura en la posicion del array que
	 * se le indique
	 */

    /**
     *
     * @param asign
     * @param posicion
     */

	public void registrarAsignatura(Asignatura asign, int posicion) {
		asignaturas[posicion] = asign;
	}
	
	/*
	 * Retorna la nota definitiva de la asignatura que se encuentra
	 * en la posicion del array indicada.
	 */

    /**
     *
     * @param posicion
     * @return nota de la asignatura en la psoicion determinada del array
     */

	public int getNotaDeAsignatura(int posicion) {
		return asignaturas[posicion].getNotaDefinitiva();
	}
	
	/*
	 * Hace un promedio general de todas las asignaturas
	 * de este estudiante
	 */

    /**
     *
     * @return promedio de notas
     */

	public int getPromedioGeneral() {
		//Sumamos las notas definitivas de sus asignaturas
		int sumaNotas = 0;
		for (Asignatura asig: asignaturas)
			sumaNotas += asig.getNotaDefinitiva();
		//Retornamos el promedio
		return sumaNotas / 5;
	}

}