/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//He cambiado el package de main a examen_03
package examen_03;

/**
 *
 * @author Victor
 */
public class Asignatura {
	//Cada asignatura tiene tres notas parciales
	private int[] parciales = new int[3];
	private String nombre;
	
    /**
     *
     * @param nombre
     */
    public Asignatura(String nombre) {
		this.nombre = nombre;
	}
	
        //He creado getters y setters de nombre y parciales
        
        /**
        * @return variable parciales
        */
        public int[] getParciales() {
           return parciales;
        }

       /**
        * @param parciales setter de parciales
        */
        public void setParciales(int[] parciales) {
           this.parciales = parciales;
        }

       /**
        * @return variable nombre
        */
        public String getNombre() {
           return nombre;
        }

       /**
        * @param nombre setter del nombre
        */
        public void setNombre(String nombre) {
           this.nombre = nombre;           
        //He añadido este PUTO corchete que lleva jodiendome el codigo todo el examen   
        }

	/*
	 * Registra una nota parcial en la posición del array que
	 * se indique.
	 */

        /**
         *
         * @param nota
         * @param posicion
         */
        public void registrarNotaParcial(int nota, int posicion) {
		nota = getParciales()[posicion];
	}

    
	/*
	 * Todas las notas tienen el mismo peso para calcular la nota
	 * definitiva. Así que basta con calcular el valor medio de las tres.
	 */

    /**
     *
     * @return nota definitiva
     */

	public int getNotaDefinitiva() {
		int sumaNotas = getParciales()[0] + getParciales()[1] + getParciales()[2];
		return sumaNotas / 3;
	}

}
